# Build Tasks — JanSetu

Dependency-ordered. Each item is written to be handed to an AI coding agent close to verbatim. Complete and test each block before moving to the next — do not build all seven days of features and test on day eight, that's how solo AI-assisted builds accumulate invisible bugs.

Consult `SETUP.md` before Day 1 — every account and key must exist first.

---

## Day 1 — Foundation

- [ ] Init Next.js 14 App Router project, TypeScript strict mode, Tailwind configured with the tokens from `DESIGN.md §2-4`
- [ ] Set up MongoDB Atlas M0 cluster, connect via `lib/db.ts` singleton pattern
- [ ] Implement all Mongoose schemas exactly per `DATA_MODEL.md` — every field, every type
- [ ] Set up the two Atlas Vector Search indexes (`problem_embedding_index`, `institution_capability_index`) — confirm embedding dimension against the actual model output first, don't guess it
- [ ] NextAuth config per `ARCHITECTURE.md §7` — four roles, credential-based
- [ ] Deploy a "hello world" version to Vercel immediately — confirms the deploy pipeline works before any real feature is built on top of it

## Day 2 — Institution data

- [ ] Source the shallow institution list: search GitHub/Kaggle for an existing pre-aggregated AICTE/UGC institution dataset (same discovery approach as the geo-boundary sourcing) rather than attempting to parse an official AISHE bulk export — AISHE does not publish one cleanly. Write `scripts/seed-institutions.ts` to parse and bulk-insert as `dataDepth: "shallow"`. Smaller and well-formed beats large and messy.
- [ ] **Parallel, non-blocking, delegate to a teammate:** manually compile 15-20 "deep" institution profiles (real department names, real faculty research areas, sourced from actual institution websites) as a first batch — doesn't require any credential or code, can start immediately and run alongside the shallow-list work
- [ ] Manually compile 40-60 "deep" institution profiles (real department names, real faculty research areas, sourced from public institution websites) — prioritize Jharkhand institutions, spread the rest across several states
- [ ] Run the embedding pipeline over every institution's `capabilityText` to populate `capabilityEmbedding`
- [ ] Verify vector search actually returns sane results with a manual test query before moving on

## Day 3-5 — AI engine (the core, per `AI_ENGINE.md`)

- [ ] Implement `lib/ai/classify.ts` exactly per the prompt in `AI_ENGINE.md §1`, Groq primary / Gemini fallback, with the invalid-response retry-once logic
- [ ] Implement `lib/ai/embed.ts` per `AI_ENGINE.md §2`
- [ ] Implement `lib/ai/dedup.ts` per `AI_ENGINE.md §3` — log every similarity score during testing
- [ ] Implement `lib/ai/match.ts` per `AI_ENGINE.md §4`, including the reason-generation prompt
- [ ] Wire `POST /api/problems` to run the full pipeline in sequence per `ARCHITECTURE.md §6`, including the `{lat,lng}` → GeoJSON `[lng,lat]` conversion flagged in `API_SPEC.md` — write a specific test for this, it's a silent-failure risk
- [ ] **Build the evaluation sets now, not later** (`AI_ENGINE.md §6`) — 150 labeled classification examples, ~50 labeled dedup pairs. Run them, record accuracy/F1. Use the dedup results to actually set the threshold in `AI_ENGINE.md §3`, replacing the 0.82 placeholder with an evidence-based number.
- [ ] Test the fallback path deliberately — kill the AI API keys temporarily and confirm a submission still saves with `needsReview: true` instead of failing

## Day 6-7 — Citizen submission flow

- [ ] Build `app/(citizen)/page.tsx` per `DESIGN.md §8` — mobile-first, single column
- [ ] Wire Web Speech API for voice input, with visible transcription the citizen can edit before submit
- [ ] Photo upload via Cloudinary
- [ ] Location: request GPS immediately on this step and pre-fill the pin the moment it resolves — do not wait for a tap. Show an equally-prominent "Set location manually" option beside the auto-detected pin (Zomato/Swiggy pattern, not a fallback-only path), letting the citizen drag the pin freely. Save `locationSource: "gps"|"manual"` and `locationAccuracyM` per `DATA_MODEL.md` — display a small "Using your current location" / "Location set manually" confirmation label so it's never ambiguous which was used. See `DESIGN.md §8` for the full UI spec.
- [ ] PWA setup: manifest, service worker, IndexedDB submission queue for offline capability — test this by actually toggling airplane mode, not just reading the code
- [ ] Public feed page with upvote
- [ ] The duplicate-detected UI moment — per `DESIGN.md §7`, this deserves a deliberate transition, it's your best demo beat

## Day 8 — Admin dashboard

- [ ] `GET /api/admin/stats` and `GET /api/admin/heatmap` implemented
- [ ] MapLibre heatmap rendering real submitted-problem coordinates
- [ ] Category breakdown chart, institution activity table
- [ ] This is the module that shows off the all-India scope decision — make sure the map convincingly shows spread across multiple states, not just Jharkhand

## Day 9 — University + Industry flows (simple, per PRD scope)

- [ ] University: institution queue view, claim action, basic status update — no approval workflow, no versioning
- [ ] Industry: browse claimed projects, pledge form
- [ ] Full integration pass — click through every flow end to end as if you were each of the four roles, fix what breaks
- [ ] QA pass, ideally by a teammate who hasn't been staring at the code

## Day 10 — Rehearsal, not code

- [ ] Do not add new features today
- [ ] Rehearse the demo script against the actual deployed app, not localhost
- [ ] Record a 2-minute backup video in case live demo connectivity fails
- [ ] Prepare honest one-liners for the known limitations (§9 of `ARCHITECTURE.md`) so nobody freezes if a judge asks

---

## Non-negotiable checkpoints

- After Day 5: the AI engine must have real accuracy/F1 numbers written down before you touch any UI. If it doesn't work well, it's cheaper to fix now than after three more days of UI built on top of it.
- After Day 7: the full citizen submission → dedup → routing loop must work end to end in the deployed app, not just locally.
- Day 10 is protected. Do not let feature work bleed into it.
